//Javascript functions called by lterProjectDescription.xsl on page load and to handle tab selection events
//
//author: Wade Sheldon <wsheldon@lternet.edu>
//version 1.1, 02-May-2009

window.onload = init;  // run init function after page load 

function init() {
    // page load init function
}
