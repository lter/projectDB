these files were copied from the EML style directory, and are for transforming EML-XML into html.
Most of the templates needed for transforming lter:researchProject docs can be lifted directly 
from these.

For the html display of the entire project:
1. lter:researchProject is a top level element now, so structure it like eml-dataset.
2. templates for these elements can probably used almost as is:
  resources (all)
  coverage (needs a template for temporalCoverage's <onging> element)
  party
  text

3. add templates from project.xsd for  funding, studyAreaDescription, designDescription

4. need new templates for new elements:
  associatedMaterial
  assocatedProject
  reporting
  permissions

