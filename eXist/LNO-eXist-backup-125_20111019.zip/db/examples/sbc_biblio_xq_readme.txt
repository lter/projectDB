SBC is using eXist for it's publications

Link to site in development (runs under coccon):
http://sbc.lternet.edu:8080/exist/sbc_bibliography/sbc_biblio.xq

best viewed in firefox
not all xsl templates or css rules are defined.




